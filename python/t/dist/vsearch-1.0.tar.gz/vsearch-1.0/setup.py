# -*- coding: utf-8 -*-
"""
Created on Wed Jun 28 09:46:45 2017

@author: Mario
"""

from setuptools import setup

setup(
        name='vsearch',
        version='1.0',
        description='just something nice',
        author='AMG',
        author_email='a@mg.com',
        url='artlabs.xyz',
        py_modules=['vsearch']
        )





