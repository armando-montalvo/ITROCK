from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def entry_page() -> 'html':
    return render_template('base.html',the_title='Search any direction!')


if __name__ == '__main__':
    app.run(debug=True)