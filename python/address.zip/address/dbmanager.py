import mysql.connector

dbconfig = {
  'host':'localhost',
  'user':'root',
  'password':'',
  'database':'google_tran',}

conn = mysql.connector.connect(**dbconfig)
cursor = conn.cursor()

def insert(id,address,latitud,longuitud):
  _SQL="""insert into address(id,address,latitud,longuitud) values (%s,%s,%s,%s)"""
  cursor.execute(_SQL,(id,address,latitud,longuitud))


def select():
  _SQL = """select * from address"""
  cursor.execute(_SQL)
  for row in cursor.fetchall():
        print(row)

def close():
  conn.commit()
  conn.close()
  cursor.close()
  conected = False