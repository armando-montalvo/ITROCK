from setuptools import setup

setup(
    name='vsearch',
    version = '1.0',
    description = 'just something nice',
    author='AMG',
    author_email='a@mg.com',
    url='artlabs.xyz',
    py_modules=['vsearch'],
)