from urllib.request import urlopen
from urllib.parse import quote
import json
from dbmanager import *

def geoloc():
    with open ('address.txt','r') as address:
        number=1
        for line in address:
            service = 'https://maps.googleapis.com/maps/api/geocode/'
            output = 'json?'
            parameteres = 'address='
            encodeUrl = quote(line)
            url = service+output+parameteres+encodeUrl
            urlData = urlopen(url)
            res=urlData.read().decode('utf-8')
            formattedData = json.loads(res)
            
            for item in formattedData['results']:
                x = item['geometry']
                y = x['location']
                lat = str(y['lat'])
                lng = str(y['lng'])
                add=str(item['formatted_address'])
                insert(number,add,lat,lng)
                number=number+1
                file = open("response.txt","a")
                file.write(item['formatted_address'])
                file.write(str(lat))
                file.write(str(lng))
                file.close()
        close()
                 
                 
                 
geoloc()        
            